# flowtrace for Python

The code repository for the Python 2 / Python 3 implementation of flowtrace.

The documentation for this repository has moved to [here](http://williamgilpin.github.io/flowtrace_docs/flowtrace_python.html)

William Gilpin, Vivek N. Prakash, and Manu Prakash, 2015



