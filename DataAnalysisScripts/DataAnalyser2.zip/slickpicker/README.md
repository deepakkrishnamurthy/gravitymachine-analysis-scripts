slickpicker
===========

It's...a colorpicker written in PyQt? Really, that's all there is to this. (can also be used as a widget)

All it's meant to do is add the html type in and screen color picking that's missing in the original QColorDialog.
