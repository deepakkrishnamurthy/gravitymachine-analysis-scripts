# -*- coding: utf-8 -*-
"""
Created on Fri Jun 22 09:36:39 2018

@author: Francois
"""
import numpy as np

a=np.array([0,1,0])
b=np.array([0,0,1])
print(np.cross(a,b))